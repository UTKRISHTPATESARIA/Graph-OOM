.. cmake-module:: ../../rapids-cmake/cython/init.cmake
