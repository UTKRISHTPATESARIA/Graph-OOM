.. cmake-module:: ../../rapids-cmake/cmake/install_lib_dir.cmake
