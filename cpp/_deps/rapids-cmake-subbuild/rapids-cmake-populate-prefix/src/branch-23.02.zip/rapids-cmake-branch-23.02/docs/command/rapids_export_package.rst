.. cmake-module:: ../../rapids-cmake/export/package.cmake
