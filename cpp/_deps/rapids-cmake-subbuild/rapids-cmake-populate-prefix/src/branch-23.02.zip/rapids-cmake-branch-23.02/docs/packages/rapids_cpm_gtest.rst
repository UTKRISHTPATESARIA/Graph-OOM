.. cmake-module:: ../../rapids-cmake/cpm/gtest.cmake
