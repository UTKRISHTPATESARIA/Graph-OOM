.. cmake-module:: ../../rapids-cmake/export/cpm.cmake
