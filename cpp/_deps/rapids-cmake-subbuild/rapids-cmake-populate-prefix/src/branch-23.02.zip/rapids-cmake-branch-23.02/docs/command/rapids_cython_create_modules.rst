.. cmake-module:: ../../rapids-cmake/cython/create_modules.cmake
