.. cmake-module:: ../../rapids-cmake/cmake/build_type.cmake
